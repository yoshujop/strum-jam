import sys, re, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
hosted_url = sys.argv[1] if len(sys.argv) > 1 else ''
head = open('src/01-head.html').read()
parts = ['05-settings.js','10-theory.js','20-songs.js','30-audio.js','35-music.js','36-sfx.js','40-mic.js','45-ear.js','46-listen.js','50-render.js','52-drummer.js','60-game.js','70-ui.js']
js = '\n'.join(open('src/'+p).read() for p in parts)
# the neural listener's engine and model, embedded so the page needs no network
import json, base64
V = 'vendor/'
def esc(t): return json.dumps(t).replace('</', '<\\/')
assets = ('/* Note recognition: Basic Pitch model (c) Spotify AB and TensorFlow.js (c) Google LLC, both under the Apache License 2.0 (https://www.apache.org/licenses/LICENSE-2.0). */\n' + 'const LISTEN_ASSETS = {scripts: [' + ','.join(esc(open(V + f).read()) for f in ['tf-core.min.js', 'tf-backend-cpu.min.js', 'tf-converter.min.js', 'tf-backend-wasm.min.js']) + '],'
  + 'wasm: "' + base64.b64encode(open(V + 'tfjs-backend-wasm.wasm', 'rb').read()).decode() + '",'
  + 'wasmSimd: "' + base64.b64encode(open(V + 'tfjs-backend-wasm-simd.wasm', 'rb').read()).decode() + '",'
  + 'model: ' + json.dumps(json.load(open(V + 'model.json'))) + ','
  + 'weights: "' + base64.b64encode(open(V + 'group1-shard1of1.bin', 'rb').read()).decode() + '"};\n')
js = assets + js
frag = head + '\n<script>\n' + js + '\n</script>\n'
os.makedirs('dist', exist_ok=True)
open('dist/index.html','w').write(frag)
i = frag.index('<!-- ============ TITLE')
local_js = js.replace("const HOSTED_URL = '__HOSTED_URL__';", "const HOSTED_URL = %r;" % hosted_url)
local = ('<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n'
         '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'
         + head[:head.index('<!-- ============ TITLE')] + '</head>\n<body>\n'
         + head[head.index('<!-- ============ TITLE'):] + '\n<script>\n' + local_js + '\n</script>\n</body>\n</html>\n')
open('dist/strum-jam.html','w').write(local)
print(len(frag), len(local))
